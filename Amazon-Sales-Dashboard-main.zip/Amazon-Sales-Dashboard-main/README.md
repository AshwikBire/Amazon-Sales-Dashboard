# Amazon-Sales-Dashboard

This  interactive Dashboard is created Using Power BI  and Data set is taken from kaggle
Thank you!!!!

![image](https://github.com/DataScientistKaustubh/Amazon-Sales-Dashboard/assets/117342376/e9487edb-8b77-451e-bc81-be930034695d)
